package com.ssafy.happyhouse.model.dao;

import java.util.List;

import com.ssafy.happyhouse.model.dto.Commercial;
import com.ssafy.happyhouse.model.dto.Environment;
import com.ssafy.happyhouse.model.dto.LocationCode;

public interface AreaDao {
	
	/**
	 * 지역 정보를 csv 파일에서 로딩하는 기능
	 */
	public void loadData();
	
	/**
	 * 	검색 조건 (key)에 해당하는 상권 리스트 반환
	 *  @param dong	어떤 동의 상권 정보를 얻어올 것인지
	 *  @return 해당 동의 상권 목록
	 */
	public List<Commercial> getCommercial(String dong);
	
	/**
	 * 해당 동의 환경 정보 반환
	 * @param dong
	 * @return 해당 동의 환경 정보 반환
	 */
	public Environment getEnvirData(String gu);

	/**
	 * 시군구 코드를 지역구 이름과 맵핑
	 * @param code
	 * @return 
	 */
	public LocationCode getLocationCode(int code);
}
