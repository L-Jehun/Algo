package com.ssafy.happyhouse.model.dao;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.dto.Commercial;
import com.ssafy.happyhouse.model.dto.Environment;
import com.ssafy.happyhouse.model.dto.LocationCode;
import com.ssafy.happyhouse.util.CSVParser;

public class AreaDaoImpl implements AreaDao {
	
	private Map<String, List<Commercial>> commercials;
	private Map<String,Environment> environments;
	private Map<Integer,LocationCode> locationCodes;
	
	public AreaDaoImpl() {
		loadData();
	}
	public void loadData() {
		CSVParser parser = new CSVParser();
		commercials = parser.getCommercials();
		environments = parser.getEnvironments();
		locationCodes = parser.getLocationCodes();
	}

	@Override
	public List<Commercial> getCommercial(String dong) {
		return commercials.get(dong);
	}

	@Override
	public Environment getEnvirData(String gu) {
		return environments.get(gu);
	}
	
	@Override
	public LocationCode getLocationCode(int code) {
		return locationCodes.get(code);
	}
	
	
	

}
