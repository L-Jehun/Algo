package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.Commercial;
import com.ssafy.happyhouse.model.dto.Environment;

public interface AreaService {

	/**
	 * 	검색 조건 (key)에 해당하는 상권 리스트 반환
	 *  @param dong	어떤 동의 상권 정보를 얻어올 것인지
	 *  @return 해당 동의 상권 목록
	 */
	public List<String> getCommerical(String dong);
	
	/**
	 * 해당 동의 환경 정보 반환
	 * @param gu
	 * @return 해당 구의 환경 정보 반환
	 */
	public Environment getEnvironment(int code);
}
