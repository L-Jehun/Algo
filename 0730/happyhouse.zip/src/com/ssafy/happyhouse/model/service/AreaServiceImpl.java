package com.ssafy.happyhouse.model.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.dao.AreaDao;
import com.ssafy.happyhouse.model.dao.AreaDaoImpl;
import com.ssafy.happyhouse.model.dto.Commercial;
import com.ssafy.happyhouse.model.dto.Environment;
import com.ssafy.happyhouse.model.dto.LocationCode;

public class AreaServiceImpl implements AreaService {
	private AreaDao dao;
	private Map<String, List<String>> amountCategory;
	
	public AreaServiceImpl() {
		dao = new AreaDaoImpl();
		amountCategory = new HashMap<>();
	}
	
	@Override
	public List<String> getCommerical(String dong) {
		if(amountCategory.containsKey(dong))
			return amountCategory.get(dong);
		List<Commercial> temp = dao.getCommercial(dong);
		Map<String, Integer> nameTag = new HashMap<>();
		ArrayList<CommercialData> array = new ArrayList<>();
		for(Commercial c : temp) {
			String name = c.getLargeCategoryName();
			if(nameTag.containsKey(name)) {
				array.get(nameTag.get(name)).count++;
			}
			else {
				nameTag.put(name, array.size());
				array.add(new CommercialData(name,1));
			}
		}	
		Collections.sort(array);
		List<String> result = new LinkedList<>();
		for(int i=0;i<3 && i < array.size() ; i++)
			result.add(array.get(i).name +" ( "+array.get(i).count+" )");
		
		return result;
	}

	@Override
	public Environment getEnvironment(int code) {
		LocationCode location = dao.getLocationCode(code);
		return dao.getEnvirData(location.getSigunguName());
	}

	class CommercialData implements Comparable<CommercialData>{
		private String name;
		private int count;
		
		
		public CommercialData(String name, int count) {
			super();
			this.name = name;
			this.count = count;
		}

		@Override
		public int compareTo(CommercialData o) {
			// TODO Auto-generated method stub
			return o.count - count;
		}
		
		
		
	}
	
}
