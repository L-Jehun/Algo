package com.ssafy.happyhouse.model.dto;

import com.opencsv.bean.CsvBindByPosition;

public class Commercial {
	@CsvBindByPosition(position = 0)
	private String no;
	
	@CsvBindByPosition(position = 1)
	private String businessName;
	
	@CsvBindByPosition(position = 2)
	private String branchName;
	
	@CsvBindByPosition(position = 3)
	private String industryCode;
	 
	@CsvBindByPosition(position = 4)
	private String largeCategoryName;
	
	@CsvBindByPosition(position = 5)
	private String middleCategoryName;
	
	@CsvBindByPosition(position = 6)
	private String subCategoryName;
	
	@CsvBindByPosition(position = 7)
	private String standardCode;
	
	@CsvBindByPosition(position = 8)
	private String cityCode;
	
	@CsvBindByPosition(position = 9)
	private String cityName;
	
	@CsvBindByPosition(position = 10)
	private String townCode;
	
	@CsvBindByPosition(position = 11)
	private String townName;
	
	@CsvBindByPosition(position = 12)
	private String adminDongCode;
	
	@CsvBindByPosition(position = 13)
	private String adminDongName;
	
	@CsvBindByPosition(position = 14)
	//@CsvBindByName(column = "법정동코드")
	private String dongCode;
	
	@CsvBindByPosition(position = 15)
//	@CsvBindByName(column = "법정동명")
	private String dongName;
	
	@CsvBindByPosition(position = 16)
//	@CsvBindByName(column = "건물명")
	private String buildingName;
	
	@CsvBindByPosition(position = 17)
//	@CsvBindByName(column = "도로명주소")
	private String streetAddress;

	@CsvBindByPosition(position = 18)
//	@CsvBindByName(column = "신우편번호")
	private String zipCode;
	
	@CsvBindByPosition(position = 19)
//	@CsvBindByName(column = "동정보")
	private String buildingDong;
	
	@CsvBindByPosition(position = 20)
//	@CsvBindByName(column = "층정보")
	private String floor;

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getIndustryCode() {
		return industryCode;
	}

	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}

	public String getLargeCategoryName() {
		return largeCategoryName;
	}

	public void setLargeCategoryName(String largeCategoryName) {
		this.largeCategoryName = largeCategoryName;
	}

	public String getMiddleCategoryName() {
		return middleCategoryName;
	}

	public void setMiddleCategoryName(String middleCategoryName) {
		this.middleCategoryName = middleCategoryName;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public String getStandardCode() {
		return standardCode;
	}

	public void setStandardCode(String standardCode) {
		this.standardCode = standardCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getTownCode() {
		return townCode;
	}

	public void setTownCode(String townCode) {
		this.townCode = townCode;
	}

	public String getTownName() {
		return townName;
	}

	public void setTownName(String townName) {
		this.townName = townName;
	}

	public String getAdminDongCode() {
		return adminDongCode;
	}

	public void setAdminDongCode(String adminDongCode) {
		this.adminDongCode = adminDongCode;
	}

	public String getAdminDongName() {
		return adminDongName;
	}

	public void setAdminDongName(String adminDongName) {
		this.adminDongName = adminDongName;
	}

	public String getDongCode() {
		return dongCode;
	}

	public void setDongCode(String dongCode) {
		this.dongCode = dongCode;
	}

	public String getDongName() {
		return dongName;
	}

	public void setDongName(String dongName) {
		this.dongName = dongName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getBuildingDong() {
		return buildingDong;
	}

	public void setBuildingDong(String buildingDong) {
		this.buildingDong = buildingDong;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Commercial] 업소번호: " + no + ", 상호명 : "+businessName + ", 지점명 : " + branchName;
	}
	
}
