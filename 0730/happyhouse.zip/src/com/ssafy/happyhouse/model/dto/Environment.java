package com.ssafy.happyhouse.model.dto;

import java.util.Date;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class Environment {
	// 환경 정보 클래스 채워주세요.
	@CsvBindByPosition(position = 0)
	private String measureDate;
	@CsvBindByPosition(position = 1)
	private String measureSiteCode;
	@CsvBindByPosition(position = 2)
	private String measureSiteName;
	
	@CsvBindByPosition(position = 3)
	private String environGrade;
	
	@CsvBindByPosition(position = 4)
	private String environJisu;
	
	@CsvBindByPosition(position = 5)
	private String indexCryst;
	
	@CsvBindByPosition(position = 6)
	private String ntdxdCncnt;
	
	@CsvBindByPosition(position = 7)
	private String ozoneCncnt;
	
	@CsvBindByPosition(position = 8)
	private String crbmnCncnt;
	
	@CsvBindByPosition(position = 9)
	private String slfdxCncnt;
	
	@CsvBindByPosition(position = 10)
	private String cncntFnds;
	
	@CsvBindByPosition(position = 11)
	private String uldstCncnt;


	public String getMeasureDate() {
		return measureDate;
	}


	public void setMeasureDate(String measureDate) {
		this.measureDate = measureDate;
	}


	public String getMeasureSiteCode() {
		return measureSiteCode;
	}


	public void setMeasureSiteCode(String measureSiteCode) {
		this.measureSiteCode = measureSiteCode;
	}


	public String getMeasureSiteName() {
		return measureSiteName;
	}


	public void setMeasureSiteName(String measureSiteName) {
		this.measureSiteName = measureSiteName;
	}


	public String getEnvironGrade() {
		return environGrade;
	}


	public void setEnvironGrade(String environGrade) {
		this.environGrade = environGrade;
	}


	public String getEnvironJisu() {
		return environJisu;
	}


	public void setEnvironJisu(String environJisu) {
		this.environJisu = environJisu;
	}


	public String getIndexCryst() {
		return indexCryst;
	}


	public void setIndexCryst(String indexCryst) {
		this.indexCryst = indexCryst;
	}


	public String getNtdxdCncnt() {
		return ntdxdCncnt;
	}


	public void setNtdxdCncnt(String ntdxdCncnt) {
		this.ntdxdCncnt = ntdxdCncnt;
	}


	public String getOzoneCncnt() {
		return ozoneCncnt;
	}


	public void setOzoneCncnt(String ozoneCncnt) {
		this.ozoneCncnt = ozoneCncnt;
	}


	public String getCrbmnCncnt() {
		return crbmnCncnt;
	}


	public void setCrbmnCncnt(String crbmnCncnt) {
		this.crbmnCncnt = crbmnCncnt;
	}


	public String getSlfdxCncnt() {
		return slfdxCncnt;
	}


	public void setSlfdxCncnt(String slfdxCncnt) {
		this.slfdxCncnt = slfdxCncnt;
	}


	public String getCncntFnds() {
		return cncntFnds;
	}


	public void setCncntFnds(String cncntFnds) {
		this.cncntFnds = cncntFnds;
	}


	public String getUldstCncnt() {
		return uldstCncnt;
	}


	public void setUldstCncnt(String uldstCncnt) {
		this.uldstCncnt = uldstCncnt;
	}


	@Override
	public String toString() {
		return "Environment [measureDate=" + measureDate + ", measureSiteCode=" + measureSiteCode + ", measureSiteName="
				+ measureSiteName + ", environGrade=" + environGrade + ", environJisu=" + environJisu + ", indexCryst="
				+ indexCryst + ", ntdxdCncnt=" + ntdxdCncnt + ", ozoneCncnt=" + ozoneCncnt + ", crbmnCncnt="
				+ crbmnCncnt + ", slfdxCncnt=" + slfdxCncnt + ", cncntFnds=" + cncntFnds + ", uldstCncnt=" + uldstCncnt
				+ "]";
	}


}
