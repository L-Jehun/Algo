package com.ssafy.happyhouse.model.dto;

import com.opencsv.bean.CsvBindByPosition;

public class LocationCode {
	@CsvBindByPosition(position = 0)
	private String sigunguCode;
	
	@CsvBindByPosition(position = 1)
	private String bupjungdongCode;
	
	@CsvBindByPosition(position = 2)
	private String hangjungdongCode;
	
	@CsvBindByPosition(position = 3)
	private String sidoName;
	
	@CsvBindByPosition(position = 4)
	private String sigunguName;
	
	@CsvBindByPosition(position = 5)
	private String bupjungdongName;
	
	@CsvBindByPosition(position = 6)
	private String hangjungdongName;
	
	@CsvBindByPosition(position = 7)
	private String startDate;
	
	@CsvBindByPosition(position = 8)
	private String endDate;
	
	public String getSigunguCode() {
		return sigunguCode;
	}
	public void setSigunguCode(String sigunguCode) {
		this.sigunguCode = sigunguCode;
	}
	public String getBupjungdongCode() {
		return bupjungdongCode;
	}
	public void setBupjungdongCode(String bupjungdongCode) {
		this.bupjungdongCode = bupjungdongCode;
	}
	public String getHangjungdongCode() {
		return hangjungdongCode;
	}
	public void setHangjungdongCode(String hangjungdongCode) {
		this.hangjungdongCode = hangjungdongCode;
	}
	public String getSidoName() {
		return sidoName;
	}
	public void setSidoName(String sidoName) {
		this.sidoName = sidoName;
	}
	public String getSigunguName() {
		return sigunguName;
	}
	public void setSigunguName(String sigunguName) {
		this.sigunguName = sigunguName;
	}
	public String getBupjungdongName() {
		return bupjungdongName;
	}
	public void setBupjungdongName(String bupjungdongName) {
		this.bupjungdongName = bupjungdongName;
	}
	public String getHangjungdongName() {
		return hangjungdongName;
	}
	public void setHangjungdongName(String hangjungdongName) {
		this.hangjungdongName = hangjungdongName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "LocationCode [sigunguCode=" + sigunguCode + ", bupjungdongCode=" + bupjungdongCode
				+ ", hangjungdongCode=" + hangjungdongCode + ", sidoName=" + sidoName + ", sigunguName=" + sigunguName
				+ ", bupjungdongName=" + bupjungdongName + ", hangjungdongName=" + hangjungdongName + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}
		
}
