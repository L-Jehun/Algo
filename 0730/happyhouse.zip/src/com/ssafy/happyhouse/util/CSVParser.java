package com.ssafy.happyhouse.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.Map;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ssafy.happyhouse.model.dto.Commercial;
import com.ssafy.happyhouse.model.dto.Environment;
import com.ssafy.happyhouse.model.dto.LocationCode;


public class CSVParser {
	
	private Map<String, List<Commercial>> commercials;
	private Map<String,Environment> environments;
	private Map<Integer,LocationCode> locationCodes;
	
	public CSVParser() {
		loadData();
	}
	
	private void loadData() {
		String commercialPath = "202106.csv";
		String environmentPath = "environ.csv";
		String locationCodePath = "locationcode.csv";
		
		try {
			CommercialHandler commercialHandler = new CommercialHandler();
			commercialHandler.parse(commercialPath);
			commercials = commercialHandler.getCommercials();
			
			EnvironmentHandler environmentHandler = new EnvironmentHandler();
			environmentHandler.parser(environmentPath);
			environments = environmentHandler.getEnvironments();
			
			LocationCodeHandler locationCodeHandler = new LocationCodeHandler();
			locationCodeHandler.parser(locationCodePath);
			locationCodes = locationCodeHandler.getLocationCodes();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public Map<String, List<Commercial>> getCommercials() {
		return commercials;
	}

	public void setCommercials(Map<String, List<Commercial>> commercials) {
		this.commercials = commercials;
	}
	
	
	public Map<String, Environment> getEnvironments() {
		return environments;
	}

	public void setEnvironments(Map<String, Environment> environments) {
		this.environments = environments;
	}

	public Map<Integer, LocationCode> getLocationCodes() {
		return locationCodes;
	}

	public void setLocationCodes(Map<Integer, LocationCode> locationCodes) {
		this.locationCodes = locationCodes;
	}

	public static void main(String[] args) {
		new CSVParser();
	}
	
}
