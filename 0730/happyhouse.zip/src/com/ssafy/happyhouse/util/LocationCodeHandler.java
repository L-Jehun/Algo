package com.ssafy.happyhouse.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ssafy.happyhouse.model.dto.Environment;
import com.ssafy.happyhouse.model.dto.LocationCode;

public class LocationCodeHandler {
	private Map<Integer,LocationCode> locationCodes;
	
	public LocationCodeHandler() {
		locationCodes = new HashMap<>();
	}
	
	public void parser(String uri) throws FileNotFoundException {
		List<LocationCode> list = new CsvToBeanBuilder<LocationCode>(new FileReader(uri))
				.withType(LocationCode.class)
				.withSkipLines(1)
				.build()
				.parse();
		
		for(LocationCode node : list) {
			locationCodes.put(Integer.parseInt(node.getSigunguCode()),node);
		}
	}

	public Map<Integer, LocationCode> getLocationCodes() {
		return locationCodes;
	}
}
