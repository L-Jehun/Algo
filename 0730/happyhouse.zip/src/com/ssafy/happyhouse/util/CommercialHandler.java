package com.ssafy.happyhouse.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ssafy.happyhouse.model.dto.Commercial;

public class CommercialHandler {

	private Map<String, List<Commercial>> list;
	
	public CommercialHandler() {
		list = new HashMap<>();
	}
	
	private void dataProcessing(List<Commercial> datas) {
		for(Commercial c : datas) {
			String dong = c.getDongName();
			if(!list.containsKey(dong))
				list.put(dong, new ArrayList<>());
			list.get(dong).add(c);
		}
	}
	
	public void parse(String uri) throws FileNotFoundException { 
		dataProcessing(new CsvToBeanBuilder<Commercial>(new FileReader(uri))
				.withType(Commercial.class)
				.withSkipLines(1)
				.build()
				.parse());
	}
	
	public Map<String, List<Commercial>> getCommercials() {
		return list;
	}
	
}
