package com.ssafy.happyhouse.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ssafy.happyhouse.model.dto.Environment;

public class EnvironmentHandler {
		
		private Map<String,Environment> environments;
		
		public EnvironmentHandler() {
			environments = new HashMap<>();
		}
		
		public void parser(String uri) throws FileNotFoundException {
			List<Environment> list = new CsvToBeanBuilder<Environment>(new FileReader(uri))
					.withType(Environment.class)
					.withSkipLines(1)
					.build()
					.parse();
			for(Environment e : list) {
				environments.put(e.getMeasureSiteName(), e);
			}
		}

		public Map<String,Environment> getEnvironments() {
			return environments;
		}
}
