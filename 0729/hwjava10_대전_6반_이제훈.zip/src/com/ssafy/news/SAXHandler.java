package com.ssafy.news;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandler extends DefaultHandler {
	private News current;
	
	private String content;
	
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		// TODO Auto-generated method stub
		if(qName.equals("item")) {
			current = new News();
		}
	}

	public void endElement(String uri, String localName, String qName) throws SAXException {
		// TODO Auto-generated method stub
			if(current != null) {
	         if (qName.equals("title"))  {
	        	 current.setTitle(this.content);
	         } else if (qName.equals("description")) {
	        	 current.setDesc(this.content);
	         } else if (qName.equals("item")) {
	        	 NewsDAOSAXImpl.list.add(current);
	            current = null;
	         }
	      }

	}

	public void characters(char[] ch, int start, int length) throws SAXException {
		// TODO Auto-generated method stub
		content = new String(ch,start,length);
	}
	

}
