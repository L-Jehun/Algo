package hwjava05_대전_6반_이제훈;

import java.util.Arrays;


public class ProductMgr {
	int Max_Size = 100;
	Product [] products=new Product[Max_Size];
	private int size;
	
	public void add(Product product) {
		if(size<Max_Size) products[size++]=product;
		else {
			System.out.println("꽉찼습니다.");
		}
	}
	
	public Product[] list() {
		return Arrays.copyOfRange(products, 0, size);
	}
	
	public Product list(int num) {
		for(int i=0; i<num; i++) {
			if(products[i].getNumber()== num) {
				return products[i];
			}
		}
		return null;
	}
	
	public void delete(int num) {
		for(int i=0;i<size;i++) {
			if(products[i].getNumber() == num) {//중요
				products[i] = products[size-1];
				products[size]=null;
				--size;
				break;
			}
		}		
	}
	
	public void priceList(int price) {
		for(int i=0; i<size; i++) {
			if(products[i].getPrice() <= price) {
				System.out.println(products[i]);
			}
		}
	}
	
	
	
}
