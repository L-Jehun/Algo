package hwjava05_대전_6반_이제훈;


public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**/
		ProductMgr productMgr = new ProductMgr();
		//Tv t1 = new Tv(1,"Samsung2",2000000,4,54,"LCD");
		//Refrigerator r1 = new Refrigerator(2,"samsung",1000000,5,100);
		
		productMgr.add(new Tv(1,"Samsung1",2000000,4,54,"LCD"));
		productMgr.add(new Tv(2,"Samsung2",1500000,5,50,"LED"));
		productMgr.add(new Tv(3,"Samsung3",1000000,6,48,"LCD"));
		productMgr.add(new Refrigerator(4,"samsung",2000000,5,100));
		productMgr.add(new Refrigerator(5,"samsung",1500000,5,90));
		productMgr.add(new Refrigerator(6,"samsung",1000000,5,80));

		System.out.println("리스트출력-------------------------------------------");
		for(Product product: productMgr.list()) {
			System.out.println(product);
		}
		System.out.println("num 제품찾기-------------------------------------------");
		System.out.println("serch! : "+productMgr.list(2));
		System.out.println("삭제 후 출력--------------------------------------------");
		productMgr.delete(2);
		for(Product product: productMgr.list()) {
			System.out.println(product);
		}
		System.out.println("가격검색------------------------------------------");
		productMgr.priceList(1500000);
		
		
		
		
		
		
	}

}
