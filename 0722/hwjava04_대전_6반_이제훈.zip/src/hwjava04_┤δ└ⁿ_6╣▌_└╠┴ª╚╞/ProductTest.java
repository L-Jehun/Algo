package hwjava04_대전_6반_이제훈;


public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**/
		Tv t1 = new Tv(1,"Samsung2",2000000,4,54,"LCD");
		Refrigerator r1 = new Refrigerator(2,"samsung",1000000,5,100);
		
		System.out.println("**********************제품 목록**********************");
		System.out.println(t1.toString());
		System.out.println(r1.toString());
	}

}
