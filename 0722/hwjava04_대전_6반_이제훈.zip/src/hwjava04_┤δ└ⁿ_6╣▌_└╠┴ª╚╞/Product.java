package hwjava04_대전_6반_이제훈;

public class Product {
	private int number;
	private	String name;
	private	int price;
	private	int su;
	
	public Product() {}
	public Product(int number,String name,int price,int su) {
		this.number=number;
		this.name=name;
		this.price=price;
		this.su=su;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSu() {
		return su;
	}
	public void setSu(int su) {
		this.su = su;
	}
}