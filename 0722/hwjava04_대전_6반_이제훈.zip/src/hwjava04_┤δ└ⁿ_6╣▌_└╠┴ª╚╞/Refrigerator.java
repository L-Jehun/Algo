package hwjava04_대전_6반_이제훈;

public class Refrigerator extends Product {
	
	/*private int number;
	private	String name;
	private	int price;
	private	int su;*/
	private	int capacity;
	
	public Refrigerator() {}
	public Refrigerator(int number,String name,int price,int su,int capacity) {
		super(number,name,price,su);
		this.capacity=capacity;
	}
	
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	@Override
	public String toString() {
		return "Refrigerator [제품 번호=" + getNumber() + ", 제품 이름" + getName()
				+ ", 가격=" + getPrice() + ", 수량=" + getSu()+", 용량=" + capacity + "]" ;
	}
	

	
}
