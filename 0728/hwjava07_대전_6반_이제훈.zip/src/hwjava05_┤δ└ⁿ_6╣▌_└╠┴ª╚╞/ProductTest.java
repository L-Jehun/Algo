package hwjava05_대전_6반_이제훈;

import java.util.Scanner;


public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**/
		IProductMgr productMgr = ProductMgrImpl.getInstance();
		//Tv t1 = new Tv(1,"Samsung2",2000000,4,54,"LCD");
		//Refrigerator r1 = new Refrigerator(2,"samsung",1000000,5,100);
		int menu;
		int delNum;
		int sercNum;
		int price;
		String proName;
		int chanNum;
		Scanner sc = new Scanner(System.in);
		
		productMgr.add(new Tv(1,"Samsung1",2000000,4,54,"LCD"));
		productMgr.add(new Tv(2,"Samsung2",1500000,5,50,"LED"));
		productMgr.add(new Tv(3,"Samsung3",1000000,6,48,"LCD"));
		productMgr.add(new Refrigerator(4,"samsung",2000000,5,600));
		productMgr.add(new Refrigerator(5,"samsung",1500000,5,400));
		productMgr.add(new Refrigerator(6,"samsung",1000000,5,300));
		
		while(true) {
			System.out.println("-------------------메뉴-------------------");
			System.out.println("1. 상품 리스트 출력");
			System.out.println("2. 상품 번호로 검색");
			System.out.println("3. 상품 번호로 삭제");
			System.out.println("4. 상품 가격 변경");
			System.out.println("5. 상품명으로 상품검색");
			System.out.println("6. Tv 리스트 전체 출력");
			System.out.println("7. Refrigerator 리스트 전체 출력");
			System.out.println("8. 전체 재고 상품 금액 합");
			System.out.println("9. 400L 이상 냉장고 검색");
			System.out.println("10. 50L 이상 Tv 검색");
			System.out.println("0. 종료");
			System.out.println("----------------------------------------");
			System.out.print("메뉴 번호를 입력하세요 : ");
			menu = sc.nextInt();
			
			switch (menu) {
			case 1:
				for(Product product: productMgr.list()) {
					System.out.println(product);
				}
				break;
			case 2:
				System.out.print("검색할 제품 번호를 입력하세요 : ");
				sercNum = sc.nextInt();
				System.out.println("serch! : "+productMgr.list(sercNum));
				break;
			case 3:
				System.out.print("삭제할 제품 번호를 입력하세요 : ");
				delNum = sc.nextInt();
				productMgr.delete(delNum);
				break;
			case 4:
				System.out.println("상품번호와 변경할 가격을 입력하시오 ");
				chanNum = sc.nextInt();
				price = sc.nextInt();
				productMgr.changePrice(chanNum, price);
			case 5:
				System.out.println("검색할 상품명을 입력하세요");
				proName = sc.next();
				for(Product p: productMgr.searchByTitle(proName)) {
					System.out.println(p);}
				break;
			case 6:
				System.out.println("Tv 리스트 출력");
				for(Product p: productMgr.getTv()) {
					System.out.println(p);}
				break;
			case 7:
				System.out.println("Refrigerator 리스트 출력");
				for(Product p: productMgr.getRefrigerator()) {
					System.out.println(p);}
				break;
			case 8:
				System.out.println("전체 재고 총합은 : "+productMgr.getTotalPrice()+"원 입니다.");
				break;
			case 9:
				productMgr.searchRefrigeratorLitter();
				break;
			case 10:
				productMgr.searchTvInci();
				break;
			
			case 0:
				System.out.println("종료되었습니다.");
				return;
	
			default:
				break;
			}
			
		}
		
		
		
	}

}

