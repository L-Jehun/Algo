package hwjava05_대전_6반_이제훈;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProductMgrImpl implements IProductMgr {
	int Max_Size = 100;
	private List<Product> products = new ArrayList<Product>();
	
	private ProductMgrImpl(){}//외부 생성 X 클래스 내부에서 private 만듬 -> 생성자
	
	private static ProductMgrImpl instance = new ProductMgrImpl();
	
	public static IProductMgr getInstance() {
		return instance;
	}
	
	public void add(Product product) {
		products.add(product);
	}
	
	public void delete(int num) {
		int number = products.size();
		for(int i=0;i<number; i++) {
			if(products.get(i).getNumber()==num) {
				products.remove(i);
				break;
			}
		}
	}
	
	public Product[] list() {
		Product[] result = new Product[products.size()];
		return products.toArray(result);
	}
	
	public Product list(int num) {
		for(Product product : products) {
			if(product.getNumber()==num) return product;
		}
		return null;
	}
	
	
//	public Product priceList(int price) {
//		for(Product product : products) {
//			if(product.getPrice()<price) return product;
//		}
//		return null;
//	}
	
	public Product[] searchByTitle(String name) {
		ArrayList<Product> temp = new ArrayList<Product>();
		for(Product product : products) {
			if(product.getName().equals(name)) temp.add(product);
		}
		Product[]result = new Product[temp.size()];
		return temp.toArray(result);
	}
	
	public Product[] getRefrigerator() {//냉장고만
		ArrayList<Product> temp = new ArrayList<Product>();
		for(Product product:products) {
			if(!(product instanceof Tv)) temp.add(product);
		}
		Product[]result = new Product[temp.size()];
		return temp.toArray(result);
		
	}
	public Product[] getTv() {//티비만
		ArrayList<Product> temp = new ArrayList<Product>();
		for(Product product:products) {
			if(!(product instanceof Refrigerator)) temp.add(product);
		}
		Product[]result = new Product[temp.size()];
		return temp.toArray(result);
		
	}
	
	public int getTotalPrice() {
		int total =0;
		for(Product product : products) {
			total +=product.getPrice();
		}
		return total;
		
	}

	@Override
	public void searchRefrigeratorLitter() {
		for(int i = 0;i<products.size();i++) {
			if(((Refrigerator)products.get(i)).getCapacity()>=400) {
				System.out.println(products.get(i));
			}else {
				break;
			}
		}				
	}

	@Override
	public void searchTvInci() {
		for(int i = 0;i<products.size();i++) {
			if(((Tv)products.get(i)).getInch()>=50) {
				System.out.println(products.get(i));
			}else {
				break;
			}
		}	
		
	}

	@Override
	public void changePrice(int num, int price) {
		// TODO Auto-generated method stub
		Product product = list(num);
		product.setPrice(price);
	}
	
}
