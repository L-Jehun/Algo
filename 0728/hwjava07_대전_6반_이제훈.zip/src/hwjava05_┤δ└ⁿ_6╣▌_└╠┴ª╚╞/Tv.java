package hwjava05_대전_6반_이제훈;

public class Tv extends Product {
	/*private int number;
	private	String name;
	private	int price;
	private	int su;*/
	private	int inch;
	private	String type;
	
	public Tv(){}	
	public Tv(int number,String name,int price,int su,int inch,String type) {
		super(number,name,price,su);
		this.inch=inch;
		this.type=type;
	}
	

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Tv	 [제품 번호=" + getNumber() + ", 제품 이름" + getName()
		+ ", 가격=" + getPrice() + ", 수량="+ getSu()+", 인치=" + inch + ", 디스플레이 타입=" + type+ "]";	
	}
}
