package hwjava05_대전_6반_이제훈;

import java.util.Arrays;

public interface IProductMgr {
	
	public void add(Product product);//add
	
	public Product[] list();//전체 검색
	
	public Product list(int num);// 상품 번호로 검색
	
	public Product[] searchByTitle(String name); //상품명으로 검색
	
	public Product[] getTv();//TV만 검색
	
	public Product[] getRefrigerator();//냉장고만 검색
	
	//400L이상 냉장고 검색
	public void searchRefrigeratorLitter();
	//50인치 이상 TV 검색
	public void searchTvInci();
	
//	public Product priceList(int price); //얼마 이상 상품 검색 -> 가격 변경
	public void changePrice(int num, int price);//가격 변경
	
	public void delete(int num);//삭제
	
	public int getTotalPrice(); //전체 재고 상품 금액
}
