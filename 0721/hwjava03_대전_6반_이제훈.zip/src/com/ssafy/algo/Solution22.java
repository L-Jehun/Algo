package com.ssafy.algo;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Scanner;
public class Solution22 {
	static long Answer;
	static int N, S;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("Solution22.txt"));
		Scanner sc = new Scanner(System.in);

		int[] dx = {-1, +1, 0, 0};
		int[] dy = {0, 0, -1, +1}; // 1이면 하 2이면 우
		int curX = 0; // 현재위치를 저장할 변수
		int curY = 0; // 현재위치를 저장할 변수
		int direc = 0; //방향
		int T = sc.nextInt(); // testcase입력

		for (int test_case = 1; test_case <= T; test_case++) {

			int N = sc.nextInt(); // 연못 크기
			int live = sc.nextInt(); // 소금쟁이 수
			int[][] pond = new int[N][N]; // 연못
			int[][] sg = new int[live][3]; // 소금쟁이 인덱스
			int res = live;

			boolean over = false; // 중첩이 있었는지 확인할 변수
			for (int i = 0; i < live; i++) { // 소금쟁이수만큼 입력받으려고
				for (int j = 0; j < 3; j++) {// 소금쟁이 한마리당 인덱스 입력받으려고
					sg[i][j] = sc.nextInt();
				}
			}

			for (int i = 0; i < live; i++) { // 소금쟁이 한마리씩 출발
				curX = sg[i][0];// 행
				curY = sg[i][1];// 열
				direc = sg[i][2]-1;// 방향
				if (pond[curX][curY] == 1) { // 출발지에 1이면 죽음
					res--;
					break;
				}

				for (int j = 3; j >= 1; j--) { // 3칸 2칸 1칸 뜀
					curX = curX + (j * dx[direc]); // 현재 칸 증가
					curY = curY + (j * dy[direc]);
					if (curX < 0 || curX >= N || curY < 0 || curY >= N) { // 벗어나면 죽음
						res--;
						break;
					} else if (pond[curX][curY] == 1) { // 3칸 갔는데 1이면 죽음 , 2칸 갔는데 1이면 죽음,그때 순번 출력+
						res--;
						over = true; // 중첩있어서 중첩변수 바꿔줌
						break;
					} else { // 흔적없으면 흔적 남김
						pond[curX][curY] = 1;
					}

				}
			}
			if(over) {
				res++;				
			}			
			System.out.println("#" + test_case+" "+ res);
		}
	}
}
