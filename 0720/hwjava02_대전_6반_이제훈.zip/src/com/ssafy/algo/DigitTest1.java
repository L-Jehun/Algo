package com.ssafy.algo;
import java.util.Scanner;

public class DigitTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[10];
		int res;
		while(true) {
			int n = sc.nextInt();
			res = n/10;
			
			if(n==0) break;
			else if(n>100||n<0) System.out.println("범위를 벗어났습니다. 다시 입력하세요.");
			else arr[res]++;				
			}
		for(int i =1;i<10;i++) {
			System.out.println(i+": "+arr[i]+"개");
		}
	}

}
