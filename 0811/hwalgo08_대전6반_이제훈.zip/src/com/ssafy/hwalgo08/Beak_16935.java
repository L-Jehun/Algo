package com.ssafy.hwalgo08;

import java.util.Scanner;

public class Beak_16935 {

	
	static int N;
	static int M;
	static int R;
	static int [][]map;
	static int [][]res;
	static int num;
	
	public static void main(String[] args) {
		//배열 크기 재지정때문에 새로운 resmap필요
		//
		
		Scanner sc = new Scanner(System.in);
		
		N=sc.nextInt();
		M=sc.nextInt();
		R=sc.nextInt();
		map = new int[N][M];
		
		
		for(int i=0;i<N;i++) {
			for(int j=0;j<M;j++) {
				map[i][j]=sc.nextInt();
			}
		}

		num = sc.nextInt();
		for(int i=0;i<R;i++){
			switch (num) {
			case 1://상하 반전
				upDown();
				break;
			case 2://좌우 반전
				leftRight();
				break;
			case 3://오른 90
				right();
				break;
			case 4:// 오른쪽 3번 =왼쪽 90
				right();
				right();
				right();
				break;
			case 5://1group->2 2group->3 ---4group->1
				five();
				break;
			case 6:
				six();//1->4 4->3 3->2 2->1
				break;
			}
		}
		
		for(int i=0;i<N;i++) {
			for(int j=0;j<M;j++) {
				System.out.print(res[i][j]+" ");
			}
			System.out.println();
		}								
	}
	//--------------------------------------------------------
	public static void upDown() {
		res= new int[N][M];//ex N6,M8들어왔을때 //i 5 -> 0 j 그대로
		//N-i-1 5 4 3 2 1 0
		for(int i=0;i<N;i++) {
			for(int j=0;j<M;j++) {
				res[N-i-1][j]=map[i][j];
			}
		}
		map = res;
	}
	
	public static void leftRight() {//6,8 i 그대로j  0->7 1->6
		res= new int[N][M];
		for(int i=0;i<N;i++) {
			for(int j=0;j<M;j++) {
				res[i][M-j-1]=map[i][j];
			}
		}
		map = res;
	}
	
	public static void right() {
		res= new int[M][N];
		int k = N-1;
		for(int i=0;i<N;i++) {
			for(int j=0;j<M;j++) {
				res[j][k]=map[i][j];
			}
			k--;
		}
		
		int temp=N;
		N=M;
		M=temp;
		map = res;
	}
	
	//12
	//43
	public static void five() {//1group->2 2group->3 ---4group->1
		res= new int[N][M];
		
		for(int i=0;i<N/2;i++) {//1->2
			for(int j=0;j<M/2;j++) {
				res[i][M/2+j]=map[i][j];
			}
		}
		for(int i=0;i<N/2;i++) {//2->3
			for(int j=M/2;j<M;j++) {
				res[N/2+i][j]=map[i][j];
			}
		}
		for(int i=N/2;i<N;i++) {//3->4
			int r=0;
			for(int j=M/2;j<M;j++) {
				res[i][r]=map[i][j];
				r++;
			}
		}
		
		int c=0;		
		for(int i=N/2;i<N;i++) {
			for(int j=0;j<M/2;j++) {
				res[c][j]=map[i][j];				
			}
			c++;
		}
		map = res;
	}
	//12
	//43
	public static void six() {//1->4 4->3 3->2 2->1
		res= new int[N][M];
		//1->4
		for(int i=0;i<N/2;i++) {
			for(int j=0;j<M/2;j++) {
				res[N/2+i][j]=map[i][j];
			}
		}
		//4->3
		for(int i=N/2;i<N;i++) {
			for(int j=0;j<M/2;j++) {
				res[i][M/2+j]=map[i][j];
			}
		}
		//3->2
		int r=0;
		for(int i=N/2;i<N;i++) {
			for(int j=M/2;j<M;j++) {
				res[r][j]=map[i][j];
			}
			r++;
		}
		
			
		for(int i=0;i<N/2;i++) {
			int c=0;
			for(int j=M/2;j<M;j++) {
				res[i][c]=map[i][j];				
				c++;
			}
		}
	}
}
