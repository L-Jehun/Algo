package com.java.first;

public class CircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double s = 5*5*Math.PI;
		System.out.printf("반지름이 5Cm인 원의 넓이는 %f 입니다.",s);
	}

}
