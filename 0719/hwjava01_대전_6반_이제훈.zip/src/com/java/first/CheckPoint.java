package com.java.first;

import java.util.Scanner;

public class CheckPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int num1;
		int num2;
		num1 = sc.nextInt();
		num2 = sc.nextInt();
		System.out.printf("곱 = "+ "%d",num1*num2);
		System.out.println();
		System.out.printf("몫 = "+"%d",num1/num2);
	}

}
