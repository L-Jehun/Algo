package com.java.first;

import java.util.Scanner;

public class Compute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int height;
		int weight;
		height = sc.nextInt();
		weight = sc.nextInt();
		int res = weight+100-height;
		System.out.printf("비만수치는 %d 입니다.",res);
		System.out.println();
		if(res>0) {
			System.out.println("당신은 비만입니다.");
		}else {
			System.out.println("당신은 정상입니다.");
		}
	}

}
