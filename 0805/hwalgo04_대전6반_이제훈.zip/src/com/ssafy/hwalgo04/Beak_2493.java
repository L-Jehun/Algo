package com.ssafy.hwalgo04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Stack;
import java.util.StringTokenizer;

public class Beak_2493 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		//스캐너 X
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(br.readLine());
		StringTokenizer stz = new StringTokenizer(br.readLine());
		Stack<int[]> st = new Stack<>();		
		for(int i=1;i<=N;i++) {
			int top = Integer.parseInt(stz.nextToken());
			int res[] = {i,top};
			while(!st.empty()) {
			//	System.out.println("peak : "+st.peek()[1]+"top: "+ top);
				if(st.peek()[1] < top) st.pop();
				else {
					System.out.println(st.peek()[0]+" ");
					break;
				}
			}
			if(st.isEmpty()) System.out.print("0 ");
			st.push(res);
		}
	}
}
