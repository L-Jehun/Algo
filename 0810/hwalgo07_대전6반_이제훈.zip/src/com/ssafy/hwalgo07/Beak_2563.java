package com.ssafy.hwalgo07;

import java.util.Scanner;

public class Beak_2563 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int N=sc.nextInt();//색종이 수
		int x,y;
		int [][]arr = new int[100][100];
		int cnt=0;
		
		for(int i=0;i<N;i++) {
			x=sc.nextInt();
			y=sc.nextInt();
			
			for(int r=x;r<x+10;r++) {
				for(int c=y;c<y+10;c++) {
					arr[r][c]=1;				
				}
			}
		}
		
		for(int i=0;i<100;i++) {
			for(int j=0;j<100;j++) {				
				if(arr[i][j]==1) cnt++;
			}
		}
		System.out.println(cnt);
	}

}
